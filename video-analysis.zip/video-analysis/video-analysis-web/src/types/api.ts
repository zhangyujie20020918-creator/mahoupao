/**
 * API 类型定义
 */

export interface Platform {
  name: string
  value: string
  domains: string[]
}

export interface VideoInfo {
  url: string
  platform: string
  video_id: string
  title: string
  author?: string
  duration?: number
  thumbnail?: string
  description?: string
  view_count?: number
  like_count?: number
  available_qualities: string[]
}

export interface DownloadResponse {
  success: boolean
  message: string
  video_info?: VideoInfo
  file_path?: string
  file_size?: number
  file_size_human?: string
  elapsed_time?: number
}

export interface DownloadRequest {
  url: string
  platform?: string
  quality: 'best' | '1080p' | '720p' | '480p'
  audio_only: boolean
}

export type DownloadStatus = 'idle' | 'loading' | 'success' | 'error'
