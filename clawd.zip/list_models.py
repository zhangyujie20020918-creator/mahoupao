import google.generativeai as genai
import os

# 从主脚本读取 Key (或者直接替换)
# 为了方便，我直接用你刚才提供的 Key
GOOGLE_API_KEY = "AIzaSyDNfvsBJotJZMFjxDq92TLcxBEZDd_YYgw" 

genai.configure(api_key=GOOGLE_API_KEY)

print("=== 正在列出可用模型 ===")
try:
    for m in genai.list_models():
        if 'generateContent' in m.supported_generation_methods:
            print(f"- {m.name} (支持方法: {m.supported_generation_methods})")
except Exception as e:
    print(f"出错: {e}")
