/**
 * API 服务
 */

import axios from 'axios'
import type { Platform, VideoInfo, DownloadResponse, DownloadRequest } from '../types/api'

const api = axios.create({
  baseURL: '/api',
  timeout: 300000, // 5分钟超时（视频下载可能较慢）
})

/**
 * 获取支持的平台列表
 */
export async function getPlatforms(): Promise<Platform[]> {
  const { data } = await api.get<{ platforms: Platform[] }>('/platforms')
  return data.platforms
}

/**
 * 获取视频信息
 */
export async function getVideoInfo(url: string): Promise<VideoInfo> {
  const { data } = await api.post<VideoInfo>('/info', { url })
  return data
}

/**
 * 下载视频
 */
export async function downloadVideo(request: DownloadRequest): Promise<DownloadResponse> {
  const { data } = await api.post<DownloadResponse>('/download', request)
  return data
}

/**
 * 验证URL是否支持
 */
export async function validateUrl(url: string): Promise<boolean> {
  const { data } = await api.post<{ supported: boolean }>('/validate', { url })
  return data.supported
}

export default api
