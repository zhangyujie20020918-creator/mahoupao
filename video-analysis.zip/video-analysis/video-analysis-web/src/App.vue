<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { getPlatforms, downloadVideo } from './api'
import type { Platform, DownloadResponse, DownloadStatus } from './types/api'

// 状态
const platforms = ref<Platform[]>([])
const selectedPlatform = ref<string>('')
const videoUrl = ref<string>('')
const quality = ref<'best' | '1080p' | '720p' | '480p'>('best')

const status = ref<DownloadStatus>('idle')
const result = ref<DownloadResponse | null>(null)
const errorMessage = ref<string>('')

// 画质选项
const qualityOptions = [
  { value: 'best', label: '最佳画质' },
  { value: '1080p', label: '1080P' },
  { value: '720p', label: '720P' },
  { value: '480p', label: '480P' },
] as const

// 加载平台列表
onMounted(async () => {
  try {
    platforms.value = await getPlatforms()
    if (platforms.value.length > 0) {
      selectedPlatform.value = platforms.value[0].value
    }
  } catch (e) {
    console.error('加载平台列表失败:', e)
  }
})

// 格式化时长
function formatDuration(seconds?: number): string {
  if (!seconds) return '-'
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
  }
  return `${m}:${s.toString().padStart(2, '0')}`
}

// 提交下载
async function handleSubmit() {
  if (!videoUrl.value.trim()) {
    errorMessage.value = '请输入视频URL'
    return
  }

  status.value = 'loading'
  result.value = null
  errorMessage.value = ''

  try {
    const response = await downloadVideo({
      url: videoUrl.value.trim(),
      platform: selectedPlatform.value,
      quality: quality.value,
      audio_only: false,
    })

    result.value = response
    status.value = response.success ? 'success' : 'error'

    if (!response.success) {
      errorMessage.value = response.message
    }
  } catch (e: any) {
    status.value = 'error'
    errorMessage.value = e.response?.data?.detail || e.message || '下载失败'
  }
}
</script>

<template>
  <div class="container">
    <header>
      <h1 class="title">Video Downloader</h1>
      <p class="subtitle">支持 YouTube / TikTok / Bilibili / 小红书</p>
    </header>

    <div class="card">
      <form @submit.prevent="handleSubmit">
        <!-- 平台选择 -->
        <div class="form-group">
          <label class="form-label">选择平台</label>
          <select v-model="selectedPlatform" class="form-select">
            <option v-for="p in platforms" :key="p.value" :value="p.value">
              {{ p.name }}
            </option>
          </select>
        </div>

        <!-- URL输入 -->
        <div class="form-group">
          <label class="form-label">视频链接</label>
          <input
            v-model="videoUrl"
            type="text"
            class="form-input"
            placeholder="粘贴视频URL..."
            :disabled="status === 'loading'"
          />
        </div>

        <!-- 画质选择 -->
        <div class="form-group">
          <label class="form-label">画质</label>
          <div class="quality-options">
            <button
              v-for="q in qualityOptions"
              :key="q.value"
              type="button"
              class="quality-option"
              :class="{ active: quality === q.value }"
              @click="quality = q.value"
            >
              {{ q.label }}
            </button>
          </div>
        </div>

        <!-- 提交按钮 -->
        <button type="submit" class="btn btn-primary" :disabled="status === 'loading'">
          <span v-if="status === 'loading'" class="spinner"></span>
          {{ status === 'loading' ? '下载中...' : '开始下载' }}
        </button>
      </form>
    </div>

    <!-- 结果展示 -->
    <div v-if="result" class="card result-card" :class="result.success ? 'result-success' : 'result-error'">
      <h3 class="result-title">
        <span v-if="result.success">✓</span>
        <span v-else>✗</span>
        {{ result.success ? '下载成功' : '下载失败' }}
      </h3>

      <div v-if="result.success && result.video_info" class="result-info">
        <div class="result-row">
          <span class="result-label">标题</span>
          <span class="result-value">{{ result.video_info.title }}</span>
        </div>
        <div v-if="result.video_info.author" class="result-row">
          <span class="result-label">作者</span>
          <span class="result-value">{{ result.video_info.author }}</span>
        </div>
        <div class="result-row">
          <span class="result-label">时长</span>
          <span class="result-value">{{ formatDuration(result.video_info.duration) }}</span>
        </div>
        <div v-if="result.file_size_human" class="result-row">
          <span class="result-label">文件大小</span>
          <span class="result-value">{{ result.file_size_human }}</span>
        </div>
        <div v-if="result.elapsed_time" class="result-row">
          <span class="result-label">耗时</span>
          <span class="result-value">{{ result.elapsed_time.toFixed(1) }}秒</span>
        </div>
        <div v-if="result.file_path" class="result-row">
          <span class="result-label">保存位置</span>
          <span class="result-value">{{ result.file_path }}</span>
        </div>
      </div>

      <div v-if="!result.success" class="result-info">
        <p>{{ result.message }}</p>
      </div>
    </div>

    <!-- 错误提示 -->
    <div v-if="status === 'error' && errorMessage && !result" class="card result-card result-error">
      <h3 class="result-title">✗ 错误</h3>
      <p>{{ errorMessage }}</p>
    </div>
  </div>
</template>
