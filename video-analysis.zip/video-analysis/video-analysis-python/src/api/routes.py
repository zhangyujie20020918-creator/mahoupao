"""
API 路由
"""

import asyncio
from pathlib import Path
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse

from src.services import DownloadService
from src.core.exceptions import DownloaderError, UnsupportedPlatformError
from src.config import get_settings
from .schemas import (
    DownloadRequest,
    DownloadResponse,
    VideoInfoRequest,
    VideoInfoResponse,
    PlatformsResponse,
    PlatformInfo,
    DownloadProgressResponse,
    ErrorResponse,
)

router = APIRouter(tags=["Video Download"])

# 下载任务状态存储（生产环境应使用Redis）
download_tasks: dict = {}


def get_service() -> DownloadService:
    """获取下载服务实例"""
    return DownloadService()


@router.get(
    "/platforms",
    response_model=PlatformsResponse,
    summary="获取支持的平台列表",
)
async def get_platforms():
    """返回所有支持的视频平台"""
    platforms = [
        PlatformInfo(
            name="YouTube",
            value="youtube",
            domains=["youtube.com", "youtu.be"],
        ),
        PlatformInfo(
            name="TikTok",
            value="tiktok",
            domains=["tiktok.com", "vm.tiktok.com", "vt.tiktok.com"],
        ),
        PlatformInfo(
            name="抖音",
            value="douyin",
            domains=["douyin.com", "v.douyin.com", "iesdouyin.com"],
        ),
        PlatformInfo(
            name="Bilibili",
            value="bilibili",
            domains=["bilibili.com", "b23.tv"],
        ),
        PlatformInfo(
            name="小红书",
            value="rednote",
            domains=["xiaohongshu.com", "xhslink.com"],
        ),
    ]
    return PlatformsResponse(platforms=platforms)


@router.post(
    "/info",
    response_model=VideoInfoResponse,
    responses={400: {"model": ErrorResponse}},
    summary="获取视频信息",
)
async def get_video_info(request: VideoInfoRequest):
    """获取视频详细信息（不下载）"""
    service = get_service()

    try:
        info = await service.get_info(request.url)
        return VideoInfoResponse(
            url=info.url,
            platform=info.platform.name,
            video_id=info.video_id,
            title=info.title,
            author=info.author,
            duration=info.duration,
            thumbnail=info.thumbnail,
            description=info.description,
            view_count=info.view_count,
            like_count=info.like_count,
            available_qualities=info.available_qualities,
        )
    except UnsupportedPlatformError as e:
        raise HTTPException(status_code=400, detail=f"不支持的平台: {e.url}")
    except DownloaderError as e:
        raise HTTPException(status_code=400, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/download",
    response_model=DownloadResponse,
    responses={400: {"model": ErrorResponse}},
    summary="下载视频",
)
async def download_video(request: DownloadRequest):
    """
    同步下载视频

    注意：对于大文件，建议使用异步下载接口 /download/async
    """
    service = get_service()
    settings = get_settings()

    try:
        result = await service.download(
            url=request.url,
            output_dir=settings.download.output_dir,
            quality=request.quality.value,
            audio_only=request.audio_only,
        )

        if result.success:
            return DownloadResponse(
                success=True,
                message="下载成功" + ("（含字幕）" if result.subtitle_path else ""),
                video_info=VideoInfoResponse(
                    url=result.video_info.url,
                    platform=result.video_info.platform.name,
                    video_id=result.video_info.video_id,
                    title=result.video_info.title,
                    author=result.video_info.author,
                    duration=result.video_info.duration,
                    thumbnail=result.video_info.thumbnail,
                    available_qualities=result.video_info.available_qualities,
                ),
                file_path=str(result.file_path) if result.file_path else None,
                file_size=result.file_size,
                file_size_human=result.file_size_human,
                elapsed_time=result.elapsed_time,
                subtitle_path=str(result.subtitle_path) if result.subtitle_path else None,
            )
        else:
            return DownloadResponse(
                success=False,
                message=result.error_message or "下载失败",
            )

    except UnsupportedPlatformError as e:
        raise HTTPException(status_code=400, detail=f"不支持的平台: {e.url}")
    except DownloaderError as e:
        raise HTTPException(status_code=400, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/download/async",
    response_model=DownloadProgressResponse,
    summary="异步下载视频",
)
async def download_video_async(
    request: DownloadRequest,
    background_tasks: BackgroundTasks,
):
    """
    异步下载视频，返回任务ID用于查询进度
    """
    task_id = str(uuid4())

    # 初始化任务状态
    download_tasks[task_id] = {
        "status": "pending",
        "progress": 0,
        "speed": None,
        "eta": None,
        "error": None,
        "result": None,
    }

    # 后台执行下载
    background_tasks.add_task(
        _execute_download,
        task_id,
        request.url,
        request.quality.value,
        request.audio_only,
    )

    return DownloadProgressResponse(
        task_id=task_id,
        status="pending",
        progress=0,
    )


async def _execute_download(
    task_id: str,
    url: str,
    quality: str,
    audio_only: bool,
):
    """后台执行下载任务"""
    service = get_service()
    settings = get_settings()

    try:
        download_tasks[task_id]["status"] = "downloading"

        result = await service.download(
            url=url,
            output_dir=settings.download.output_dir,
            quality=quality,
            audio_only=audio_only,
        )

        if result.success:
            download_tasks[task_id].update({
                "status": "completed",
                "progress": 100,
                "result": {
                    "file_path": str(result.file_path),
                    "file_size": result.file_size,
                    "subtitle_path": str(result.subtitle_path) if result.subtitle_path else None,
                },
            })
        else:
            download_tasks[task_id].update({
                "status": "failed",
                "error": result.error_message,
            })

    except Exception as e:
        download_tasks[task_id].update({
            "status": "failed",
            "error": str(e),
        })


@router.get(
    "/download/status/{task_id}",
    response_model=DownloadProgressResponse,
    summary="查询下载进度",
)
async def get_download_status(task_id: str):
    """查询异步下载任务的进度"""
    if task_id not in download_tasks:
        raise HTTPException(status_code=404, detail="任务不存在")

    task = download_tasks[task_id]
    return DownloadProgressResponse(
        task_id=task_id,
        status=task["status"],
        progress=task["progress"],
        speed=task.get("speed"),
        eta=task.get("eta"),
        error=task.get("error"),
    )


@router.get(
    "/download/file/{task_id}",
    summary="获取已下载的文件",
)
async def get_downloaded_file(task_id: str):
    """下载完成后获取文件"""
    if task_id not in download_tasks:
        raise HTTPException(status_code=404, detail="任务不存在")

    task = download_tasks[task_id]

    if task["status"] != "completed":
        raise HTTPException(status_code=400, detail="下载尚未完成")

    file_path = Path(task["result"]["file_path"])

    if not file_path.exists():
        raise HTTPException(status_code=404, detail="文件不存在")

    return FileResponse(
        path=file_path,
        filename=file_path.name,
        media_type="application/octet-stream",
    )


@router.post(
    "/validate",
    summary="验证URL是否支持",
)
async def validate_url(request: VideoInfoRequest):
    """检查URL是否受支持"""
    service = get_service()
    is_supported = service.is_url_supported(request.url)

    return {
        "url": request.url,
        "supported": is_supported,
    }


@router.post(
    "/extract-audio",
    summary="从视频提取音频",
)
async def extract_audio(
    file_path: str,
    format: str = "mp3",
    bitrate: str = "192k",
):
    """
    从视频文件提取音频

    - file_path: 视频文件路径
    - format: 输出格式 (mp3, aac, wav, flac)
    - bitrate: 比特率 (128k, 192k, 256k, 320k)
    """
    from src.services.audio_extractor import AudioExtractor

    video_path = Path(file_path)
    if not video_path.exists():
        raise HTTPException(status_code=404, detail=f"文件不存在: {file_path}")

    extractor = AudioExtractor()

    try:
        output_path = await extractor.extract_audio(
            video_path=video_path,
            format=format,
            bitrate=bitrate,
        )

        return {
            "success": True,
            "message": "音频提取成功",
            "input_file": str(video_path),
            "output_file": str(output_path),
            "format": format,
            "bitrate": bitrate,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
