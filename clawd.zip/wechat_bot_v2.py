import pyautogui
import time
import base64
import os
import sys
import pyperclip
import json
import hashlib
from datetime import datetime
from openai import OpenAI
from tavily import TavilyClient
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.ocr.v20181119 import ocr_client, models

# --- 配置区 ---

# 1. 腾讯云 OCR 配置
TENCENT_SECRET_ID = "AKIDZJqBLRSiu1vc6PVO3Wryuc9TBi6Pepto"
TENCENT_SECRET_KEY = "wkNtfMtENOI2jHcjj5FBueBUZQ5WlndS"
TENCENT_REGION    = "ap-guangzhou"

# 2. Tavily Search API 配置
TAVILY_API_KEY = "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"

# 3. DeepSeek API 配置
DEEPSEEK_API_KEY  = "sk-0b70893a7a8b4348b83f08ba3526e73b"   # 请填入你的 DeepSeek API Key
DEEPSEEK_BASE_URL = "https://api.deepseek.com"
DEEPSEEK_MODEL    = "deepseek-chat"

# 4. 机器人配置
BOT_KEYWORD = "@AI助手"
WORK_DIR    = os.getcwd()


# --- 初始化客户端 ---

try:
    cred = credential.Credential(TENCENT_SECRET_ID, TENCENT_SECRET_KEY)
    httpProfile = HttpProfile()
    httpProfile.endpoint = "ocr.tencentcloudapi.com"
    clientProfile = ClientProfile()
    clientProfile.httpProfile = httpProfile
    ocr_api_client = ocr_client.OcrClient(cred, TENCENT_REGION, clientProfile)
except Exception as e:
    print(f"[错误] 腾讯云 SDK 初始化失败: {e}")
    sys.exit(1)

deepseek_client = OpenAI(api_key=DEEPSEEK_API_KEY, base_url=DEEPSEEK_BASE_URL)
tavily_client   = TavilyClient(api_key=TAVILY_API_KEY)

last_screen_hash   = ""
answered_questions = set()


# ── 工具函数 ──────────────────────────────────────────────────

def get_image_hash(image_path):
    with open(image_path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()

def encode_image_base64(image_path):
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


# ── 截图 ─────────────────────────────────────────────────────

def capture_wechat_window():
    screenshot_path = os.path.join(WORK_DIR, "current_screen.png")
    pyautogui.screenshot().save(screenshot_path)
    return screenshot_path


# ── OCR 识别 ─────────────────────────────────────────────────

def get_screen_text_with_ocr(image_path):
    print(".", end="", flush=True)
    try:
        req = models.GeneralBasicOCRRequest()
        req.from_json_string(json.dumps({
            "ImageBase64": encode_image_base64(image_path),
            "LanguageScene": "General",
        }))
        resp = ocr_api_client.GeneralBasicOCR(req)
        return json.loads(resp.to_json_string())
    except TencentCloudSDKException as err:
        print(f"\n[OCR Error] {err}")
        return None
    except Exception as e:
        print(f"\n[Error] {e}")
        return None

def parse_ocr_result(ocr_data, screen_width):
    if not ocr_data or "TextDetections" not in ocr_data:
        return None
    detections = ocr_data["TextDetections"]
    if not detections:
        return None

    candidates = []
    for item in detections:
        text    = item["DetectedText"]
        polygon = item["ItemPolygon"]
        x, y, w = polygon["X"], polygon["Y"], polygon["Width"]
        candidates.append({"text": text, "y": y, "center_x": x + w / 2})

    candidates.sort(key=lambda k: k["y"], reverse=True)
    for item in candidates:
        text = item["text"]
        if BOT_KEYWORD not in text:
            continue
        if item["center_x"] > screen_width * 0.6:
            print(f"\n[忽略] 右侧气泡（自己发的）: {text}")
            continue
        query = text.replace(BOT_KEYWORD, "").strip().lstrip(":： ,.1234567890")
        if not query:
            print("\n[忽略] 有唤起词但无内容")
            return None
        return query
    return None


# ── Tavily 搜索 ───────────────────────────────────────────────

def tavily_search(query: str) -> str | None:
    """调用 Tavily Search API，返回拼接好的摘要文本，失败返回 None"""
    try:
        results = tavily_client.search(query=query, max_results=5)
        snippets = [r["content"] for r in results["results"] if r.get("content")]
        return "\n".join(snippets) if snippets else None
    except Exception as e:
        print(f"\n[搜索失败] {e}")
        return None


# ── 回复生成（两步）─────────────────────────────────────────────

def generate_reply(query: str) -> str | None:
    """
    第一步：Brave 搜索获取最新资讯。
    第二步：将搜索结果 + 当前日期 + 问题一起发给 DeepSeek 生成回答。
    """
    today = datetime.now().strftime("%Y年%m月%d日")

    print("\n[搜索] 正在 Tavily 搜索...")
    search_context = tavily_search(query)
    if search_context:
        print(f"[搜索] 获取到 {len(search_context.splitlines())} 条结果")
    else:
        print("[搜索] 无结果，直接问 DeepSeek")

    # 构造发给 DeepSeek 的消息
    if search_context:
        user_content = (
            f"今天日期是{today}，请以搜索结果中最新的信息为准回答。\n\n"
            f"【搜索结果】\n{search_context}\n\n"
            f"【用户问题】{query}\n\n"
            f"请用简洁友好的中文作答，100字以内，不要使用 markdown 格式。"
        )
    else:
        user_content = (
            f"今天日期是{today}。\n\n"
            f"{query}\n\n请用简洁友好的中文作答，100字以内，不要使用 markdown 格式。"
        )

    try:
        print("[DeepSeek] 生成回复中...")
        response = deepseek_client.chat.completions.create(
            model=DEEPSEEK_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": "你是一个微信群AI助手，回答简洁、准确、友好，不超过100字。",
                },
                {
                    "role": "user",
                    "content": user_content,
                },
            ],
            stream=True,
        )
        result = ""
        for chunk in response:
            delta = chunk.choices[0].delta.content
            if delta:
                result += delta
        return result.strip() or None

    except Exception as e:
        print(f"\n[错误] DeepSeek API 调用失败: {e}")
        return None


# ── 发送回复 ─────────────────────────────────────────────────

def send_reply(text):
    global last_screen_hash
    if not text:
        return
    print(f"\n[动作] 准备回复: {text}")
    pyperclip.copy(text)
    time.sleep(0.5)
    pyautogui.hotkey("ctrl", "v")
    time.sleep(0.5)
    pyautogui.press("enter")
    print("[系统] 回复已发送")
    time.sleep(3)
    last_screen_hash = get_image_hash(capture_wechat_window())


# ── 主循环 ───────────────────────────────────────────────────

def main():
    print("=== 微信 AI 助理 v2 (OCR + Brave + DeepSeek) 启动 ===")
    print(f"OCR: 腾讯云  |  搜索: Brave  |  回复: DeepSeek ({DEEPSEEK_MODEL})")

    if "YOUR_DEEPSEEK" in DEEPSEEK_API_KEY:
        print("\n[警告] 请先在代码中填入 DEEPSEEK_API_KEY！")
        return

    print("注意：请保持微信窗口前置，鼠标点击在输入框内")
    print("按 Ctrl+C 停止")

    screen_width, _ = pyautogui.size()
    print(f"屏幕宽度: {screen_width}px")

    print("请在10秒内点击微信输入框...")
    for i in range(10, 0, -1):
        print(f"{i}秒后开始监听...", end="\r")
        time.sleep(1)
    print("开始监听！      ")

    global last_screen_hash
    print("[系统] 启动完成，等待 @AI助手 消息...")

    try:
        while True:
            screenshot_path = capture_wechat_window()

            current_hash = get_image_hash(screenshot_path)
            if current_hash == last_screen_hash:
                time.sleep(15)
                continue
            last_screen_hash = current_hash

            ocr_result = get_screen_text_with_ocr(screenshot_path)
            query = parse_ocr_result(ocr_result, screen_width)

            if query:
                query_hash = hashlib.md5(query.encode()).hexdigest()
                if query_hash in answered_questions:
                    print(f"\n[忽略] 重复问题: {query[:20]}...")
                    continue

                print(f"\n[新消息] {query}")
                reply = generate_reply(query)
                if reply:
                    print(f"[AI回复] {reply}")
                    send_reply(reply)
                    answered_questions.add(query_hash)

            time.sleep(15)

    except KeyboardInterrupt:
        print("\n程序已停止")
    except Exception as e:
        print(f"\n[程序异常] {e}")


if __name__ == "__main__":
    main()
