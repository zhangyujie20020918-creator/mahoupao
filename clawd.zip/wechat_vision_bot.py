import pyautogui
import time
import asyncio
import uuid
import base64
import os
import sys
import pyperclip
import json
import hashlib
from pathlib import Path
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.ocr.v20181119 import ocr_client, models

# --- 配置区 ---

# 1. 腾讯云 OCR 配置
TENCENT_SECRET_ID = "AKIDZJqBLRSiu1vc6PVO3Wryuc9TBi6Pepto"
TENCENT_SECRET_KEY = "wkNtfMtENOI2jHcjj5FBueBUZQ5WlndS"
TENCENT_REGION = "ap-guangzhou"

# 2. ClawdBot WebSocket 配置（本地 gateway）
CLAWDBOT_WS_URL      = "ws://127.0.0.1:18789"
CLAWDBOT_IDENTITY    = str(Path.home() / ".clawdbot" / "identity" / "device.json")
CLAWDBOT_SESSION_KEY = "wechat-bot-session"   # 固定 session，保留对话上下文

# 3. 机器人配置
WECHAT_WINDOW_TITLE = "微信"
BOT_KEYWORD         = "@AI助手"
WORK_DIR            = os.getcwd()

# --- 初始化腾讯云 OCR 客户端 ---
try:
    cred = credential.Credential(TENCENT_SECRET_ID, TENCENT_SECRET_KEY)
    httpProfile = HttpProfile()
    httpProfile.endpoint = "ocr.tencentcloudapi.com"
    clientProfile = ClientProfile()
    clientProfile.httpProfile = httpProfile
    ocr_api_client = ocr_client.OcrClient(cred, TENCENT_REGION, clientProfile)
except Exception as e:
    print(f"[错误] 腾讯云 SDK 初始化失败: {e}")
    sys.exit(1)

last_screen_hash  = ""
answered_questions = set()


# ── 工具函数 ──────────────────────────────────────────────────

def get_image_hash(image_path):
    with open(image_path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()

def encode_image_base64(image_path):
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


# ── 截图 ─────────────────────────────────────────────────────

def capture_wechat_window():
    screenshot_path = os.path.join(WORK_DIR, "current_screen.png")
    pyautogui.screenshot().save(screenshot_path)
    return screenshot_path


# ── OCR 识别 ─────────────────────────────────────────────────

def get_screen_text_with_ocr(image_path):
    print(".", end="", flush=True)
    try:
        req = models.GeneralBasicOCRRequest()
        req.from_json_string(json.dumps({
            "ImageBase64": encode_image_base64(image_path),
            "LanguageScene": "General",
        }))
        resp = ocr_api_client.GeneralBasicOCR(req)
        return json.loads(resp.to_json_string())
    except TencentCloudSDKException as err:
        print(f"\n[OCR Error] {err}")
        return None
    except Exception as e:
        print(f"\n[Error] {e}")
        return None

def parse_ocr_result(ocr_data, screen_width):
    if not ocr_data or "TextDetections" not in ocr_data:
        return None
    detections = ocr_data["TextDetections"]
    if not detections:
        return None

    candidates = []
    for item in detections:
        text    = item["DetectedText"]
        polygon = item["ItemPolygon"]
        x, y, w = polygon["X"], polygon["Y"], polygon["Width"]
        candidates.append({"text": text, "y": y, "center_x": x + w / 2})

    # 从底部向上找第一个包含关键词的左侧气泡
    candidates.sort(key=lambda k: k["y"], reverse=True)
    for item in candidates:
        text = item["text"]
        if BOT_KEYWORD not in text:
            continue
        if item["center_x"] > screen_width * 0.6:
            print(f"\n[忽略] 右侧气泡（自己发的）: {text}")
            continue
        query = text.replace(BOT_KEYWORD, "").strip().lstrip(":： ,.1234567890")
        if not query:
            print("\n[忽略] 有唤起词但无内容")
            return None
        return query
    return None


# ── ClawdBot WebSocket 回复生成 ───────────────────────────────

def _b64url(data: bytes) -> str:
    return base64.b64encode(data).decode().replace("+", "-").replace("/", "_").rstrip("=")

def _b64url_decode(s: str) -> bytes:
    s = s.replace("-", "+").replace("_", "/")
    s += "=" * ((4 - len(s) % 4) % 4)
    return base64.b64decode(s)

def _load_identity():
    with open(CLAWDBOT_IDENTITY) as f:
        return json.load(f)

def _load_gateway_token() -> str:
    cfg_file = Path.home() / ".clawdbot" / "clawdbot.json"
    with open(cfg_file) as f:
        cfg = json.load(f)
    return cfg.get("gateway", {}).get("auth", {}).get("token", "")

def _pub_key_b64url(pem: str) -> str:
    from cryptography.hazmat.primitives.serialization import load_pem_public_key, Encoding, PublicFormat
    raw = load_pem_public_key(pem.encode()).public_bytes(Encoding.Raw, PublicFormat.Raw)
    return _b64url(raw)

def _sign(pem: str, payload: str) -> str:
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    key = load_pem_private_key(pem.encode(), password=None)
    return _b64url(key.sign(payload.encode()))

async def _ask_clawdbot(question: str) -> str:
    import websockets

    ident      = _load_identity()
    device_id  = ident["deviceId"]
    pub_b64url = _pub_key_b64url(ident["publicKeyPem"])
    token      = _load_gateway_token()

    CLIENT_ID   = "cli"
    CLIENT_MODE = "cli"
    ROLE        = "operator"
    SCOPES      = ["operator.write"]

    idempotency_key = str(uuid.uuid4())
    connect_req_id  = str(uuid.uuid4())
    chat_req_id     = str(uuid.uuid4())

    async with websockets.connect(CLAWDBOT_WS_URL) as ws:

        # 1. 等待 connect.challenge，取 nonce
        nonce = None
        while True:
            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
            if msg.get("type") == "event" and msg.get("event") == "connect.challenge":
                nonce = msg.get("payload", {}).get("nonce", "")
                break

        # 2. 构造签名（v2 格式，含 token + nonce）
        signed_at = int(time.time() * 1000)
        payload_str = (
            f"v2|{device_id}|{CLIENT_ID}|{CLIENT_MODE}|{ROLE}"
            f"|{','.join(SCOPES)}|{signed_at}|{token}|{nonce}"
        )
        signature = _sign(ident["privateKeyPem"], payload_str)

        # 3. 发送 connect 握手
        await ws.send(json.dumps({
            "type": "req", "id": connect_req_id, "method": "connect",
            "params": {
                "minProtocol": 3, "maxProtocol": 3,
                "client": {
                    "id": CLIENT_ID, "version": "1.0.0",
                    "platform": "win32", "mode": CLIENT_MODE,
                },
                "role": ROLE, "scopes": SCOPES,
                "auth": {"token": token},
                "device": {
                    "id": device_id, "publicKey": pub_b64url,
                    "signature": signature, "signedAt": signed_at,
                    "nonce": nonce,
                },
            },
        }))

        # 4. 等待 hello-ok
        while True:
            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
            if msg.get("type") == "res" and msg.get("id") == connect_req_id:
                if not msg.get("ok"):
                    raise RuntimeError(f"connect 失败: {msg.get('error')}")
                break

        # 5. 发送 chat.send
        await ws.send(json.dumps({
            "type": "req", "id": chat_req_id, "method": "chat.send",
            "params": {
                "sessionKey":     CLAWDBOT_SESSION_KEY,
                "message":        question,
                "deliver":        True,
                "idempotencyKey": idempotency_key,
            },
        }))

        # 6. 等待 ack
        while True:
            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
            if msg.get("type") == "res" and msg.get("id") == chat_req_id:
                if not msg.get("ok"):
                    raise RuntimeError(f"chat.send 失败: {msg.get('error')}")
                break

        # 7. 接收流式事件，直到 final / error / aborted
        result_text = ""
        while True:
            raw = await asyncio.wait_for(ws.recv(), timeout=60)
            msg = json.loads(raw)
            if msg.get("type") != "event" or msg.get("event") != "chat":
                continue
            p = msg.get("payload", {})
            if p.get("runId") != idempotency_key:
                continue
            state = p.get("state")
            if state in ("delta", "final"):
                for part in p.get("message", {}).get("content", []):
                    if isinstance(part, dict) and part.get("type") == "text":
                        result_text = part["text"]   # 服务端维护累积文本，直接覆盖即可
            if state in ("final", "error", "aborted"):
                if state == "error":
                    raise RuntimeError(f"ClawdBot 报错: {p.get('errorMessage')}")
                break

        return result_text.strip()

def generate_reply(query: str):
    """通过 ClawdBot WebSocket gateway 生成回复"""
    try:
        return asyncio.run(_ask_clawdbot(query)) or None
    except Exception as e:
        print(f"\n[错误] ClawdBot WebSocket 调用失败: {e}")
        return None


# ── 发送回复 ─────────────────────────────────────────────────

def send_reply(text):
    global last_screen_hash
    if not text:
        return
    print(f"\n[动作] 准备回复: {text}")
    pyperclip.copy(text)
    time.sleep(0.5)
    pyautogui.hotkey("ctrl", "v")
    time.sleep(0.5)
    pyautogui.press("enter")
    print("[系统] 回复已发送")
    time.sleep(3)
    last_screen_hash = get_image_hash(capture_wechat_window())


# ── 主循环 ───────────────────────────────────────────────────

def main():
    print("=== 微信 AI 助理 (OCR + ClawdBot WS) 启动 ===")
    print(f"OCR: 腾讯云  |  回复: ClawdBot WebSocket ({CLAWDBOT_WS_URL})")

    print("注意：请保持微信窗口前置，鼠标点击在输入框内")
    print("按 Ctrl+C 停止")

    screen_width, _ = pyautogui.size()
    print(f"屏幕宽度: {screen_width}px")

    print("请在10秒内点击微信输入框...")
    for i in range(10, 0, -1):
        print(f"{i}秒后开始监听...", end="\r")
        time.sleep(1)
    print("开始监听！      ")

    global last_screen_hash
    print("[系统] 启动完成，等待 @AI助手 消息...")

    try:
        while True:
            screenshot_path = capture_wechat_window()

            current_hash = get_image_hash(screenshot_path)
            if current_hash == last_screen_hash:
                time.sleep(2)
                continue
            last_screen_hash = current_hash

            ocr_result = get_screen_text_with_ocr(screenshot_path)
            query = parse_ocr_result(ocr_result, screen_width)

            if query:
                query_hash = hashlib.md5(query.encode()).hexdigest()
                if query_hash in answered_questions:
                    print(f"\n[忽略] 重复问题: {query[:20]}...")
                    continue

                print(f"\n[新消息] {query}")
                reply = generate_reply(query)
                if reply:
                    print(f"[AI回复] {reply}")
                    send_reply(reply)
                    answered_questions.add(query_hash)

            time.sleep(2)

    except KeyboardInterrupt:
        print("\n程序已停止")
    except Exception as e:
        print(f"\n[程序异常] {e}")


if __name__ == "__main__":
    main()
