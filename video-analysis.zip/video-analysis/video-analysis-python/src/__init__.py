"""
Video Downloader - 多平台视频下载工具
支持: YouTube, TikTok, Bilibili, 小红书
"""

__version__ = "0.1.0"
