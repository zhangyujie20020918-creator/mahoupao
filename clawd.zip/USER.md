# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** Human
- **What to call them:** 老板
- **Pronouns:** They/Them
- **Timezone:** Asia/Shanghai
- **Notes:** Likes to ask "What are you doing" repeatedly.

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
